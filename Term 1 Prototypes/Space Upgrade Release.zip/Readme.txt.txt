Space Upgrade


Controls:
[Z]	- Fires left wing 
[X]	- Fires central pod gun
[Y]	- Fires right wing 
[<-]	- Moves ship to the left
[->]	- Moves ship to the right

AUthors:
Austin Bowen
Callan Moore
David Dale
Jc Fowles
Jaws Prince